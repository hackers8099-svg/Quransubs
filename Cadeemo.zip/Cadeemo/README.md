# QuranCaption Studio Pro (10 Qira'at + AI Word-by-Word Sync + APK)

Mashruucan waa **QuranCaption Studio Pro** oo u dhisan qaabka **QuranCaption (Quran.com)** oo kale, laguna daray naqshadda sawirka aad soo dirtay (Suuradda Al-Xashr 59:21: ereyga la akhrinayo oo **Caddaan ifaya** ah, ereyada dhiman oo **Cawlaan/Dimmed** ah, **Dark Bottom Gradient**, iyo **Tarjumada hoose**).

---

## 🌟 Waxyaabaha uu Xambaarsan Yahay (Features)

1. **Style-ka Sawirkaaga (Word-by-Word Highlighting):**
   - Ereyada la akhriyay ama hadda socda waxay noqonayaan midab ifaya (`#FFFFFF`), halka ereyada aan weli la gaarin ay noqonayaan midab daciif ah (`#64748B`), si la mid ah sawirka aad soo lifaaqday.
   - Waxaad si xor ah u beddeli kartaa **Custom Colors** (Active Word Color, Inactive Word Color, iyo Background Gradient Color + Opacity).
2. **Dhammaan 10-ka Qiraa'aad & Riwaayadaha (10 Qira'at & Mushafs):**
   - Waxaa ku jira doorashada Riwaayadaha: **Xafs can Caasim**, **Ad-Duuri can Abuu Camr**, **Warsh can Naafic**, **Qaaluun**, **As-Suusi**, **Shucbah**, **Ibn Kathiir**, **Ibn Caamir**, **Al-Kisaa'i**, iyo **Xamzah**, oo ay weheliso **AI Auto-Detect**.
   - Waxay ku xiran tahay **King Fahd Glorious Quran Printing Complex (KFGQPC) Fonts** iyo **Quran.com API v4**.
3. **AI Automatic Audio/Video Word-by-Word Sync:**
   - Waxaad soo gelin kartaa muuqaalkaaga (`MP4`/`MOV`) ama codkaaga (`MP3`/`WAV`), ama waxaad toos u isticmaali kartaa **Quran.com Audio Word-by-Word Segments** iyo **Python WhisperX Forced Aligner** (`backend_python/ai_forced_aligner.py`).
4. **Dhoofinta Muuqaalka iyo Sawirka (MP4, MOV Alpha, PNG):**
   - **MP4 Export:** Muuqaal dhammaystiran oo leh Background Video + Gradient + Caption.
   - **MOV / WebM Alpha Export:** Muuqaal hufan (Transparent Background) oo aad dul saari karto CapCut, Premiere Pro, ama DaVinci Resolve.
   - **PNG Export:** Sawir tayo sare leh (1280x720 HD) oo Transparent ah.
5. **Auto-Build Android APK via GitHub Actions:**
   - Waxaa ku dhex jira `.github/workflows/build-apk.yml` oo si toos ah kuugu dhisaya **Android APK** markaad koodhka geliso GitHub.

---

## 🚀 Sida loogu Shubo GitHub & looga Soo Saaro APK-ga

### Tallaabada 1: Kala bixi oo Fur Faylka ZIP-ka
1. Kala soo deg faylka `QuranCaption_Pro_GitHub_APK.zip` ee hoose.
2. Ku fur (Extract) kombiyuutarkaaga galka la yiraahdo `QuranCaption_Pro_Project`.

### Tallaabada 2: Geli GitHub-kaaga (2 Qaab midkood)

#### Qaabka A: Adigoo isticmaalaya Bogga GitHub (Koombiyuutar ama Moobayl - Kuma xirna Git CLI)
1. Tag [github.com](https://github.com) oo abuur **New Repository** (u bixi tusaale ahaan `qurancaption-pro`).
2. Riix **"uploading an existing file"**.
3. Soo jiid dhammaan faylasha ku jira galka `QuranCaption_Pro_Project` (`www/`, `.github/`, `backend_python/`, `package.json`, `capacitor.config.json`, `README.md`) oo ku rid bogga.
4. Riix **"Commit changes"**.

#### Qaabka B: Adigoo isticmaalaya Git Command Line (Terminal / CMD)
```bash
cd QuranCaption_Pro_Project
git init
git add .
git commit -m "Initial commit: QuranCaption Pro with 10 Qiraat & AI Sync"
git branch -M main
git remote add origin https://github.com/MAGACAAGA/qurancaption-pro.git
git push -u origin main
```

### Tallaabada 3: Kala Soo Deg Android APK-ga
1. Isla markaad faylasha geliso GitHub, fur qaybta **Actions** ee dusha sare ee Repository-gaaga.
2. Waxaad arki doontaa workflow-ga **"Build QuranCaption Pro Android APK"** oo shaqeynaya.
3. Sug **2 ilaa 3 daqiiqo** inta uu ka dhammaanayo (calaamadda cagaaran ✅).
4. Riix workflow-ga dhammaaday, hoos u deg qaybta **Artifacts**, oo kala soo deg **`QuranCaption-Pro-APK`** (`app-debug.apk`).
