// QuranCaption Studio Pro - Core Engine
// Default verse matches the user's uploaded image: Surah Al-Hashr (59), Ayah 21
const state = {
    surah: 59,
    ayah: 21,
    riwayah: 'hafs',
    words: [
        { text: "وَتِلْكَ", start: 0.0, end: 1.4 },
        { text: "ٱلْأَمْثَـٰلُ", start: 1.4, end: 3.1 },
        { text: "نَضْرِبُهَا", start: 3.1, end: 4.8 },
        { text: "لِلنَّاسِ", start: 4.8, end: 6.5 },
        { text: "لَعَلَّهُمْ", start: 6.5, end: 8.0 },
        { text: "يَتَفَكَّرُونَ", start: 8.0, end: 10.5 }
    ],
    ayahNumberArabic: "٢١",
    translation: "We set forth such comparisons for people, so perhaps they may reflect.",
    activeWordIndex: 3, // Matches image where primeros 4 words are bright white and last 2 are dimmed!
    highlightMode: "cumulative", // 'cumulative' (like reference image) or 'single'
    activeColor: "#ffffff",
    inactiveColor: "#64748b",
    gradientColor: "#000000",
    gradientOpacity: 0.85,
    arabicFontSize: 56,
    transparentMode: false,
    isPlaying: false,
    hasCustomVideo: false
};

const canvas = document.getElementById('captionCanvas');
const ctx = canvas.getContext('2d');
const bgVideo = document.getElementById('bgVideo');
const ayahAudio = document.getElementById('ayahAudio');

// Initialize Surah Dropdown
async function initSurahs() {
    const surahSelect = document.getElementById('surahSelect');
    try {
        const res = await fetch('https://api.quran.com/api/v4/chapters');
        const data = await res.json();
        surahSelect.innerHTML = '';
        data.chapters.forEach(ch => {
            const opt = document.createElement('option');
            opt.value = ch.id;
            opt.textContent = `${ch.id}. ${ch.name_simple} (${ch.name_arabic})`;
            if (ch.id === 59) opt.selected = true;
            surahSelect.appendChild(opt);
        });
    } catch (e) {
        // Fallback offline list if no internet
        surahSelect.innerHTML = '<option value="59" selected>59. Al-Hashr (الحشر)</option><option value="1">1. Al-Fatihah (الفاتحة)</option><option value="36">36. Ya-Sin (يس)</option>';
    }
}

// Convert number to Arabic-Indic digits
function toArabicDigits(num) {
    const arabicDigits = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    return String(num).split('').map(d => arabicDigits[parseInt(d, 10)] || d).join('');
}

// Fetch Word-by-Word Data & Timestamps from Quran.com API v4
async function fetchAyahData() {
    const surah = document.getElementById('surahSelect').value || 59;
    const ayah = document.getElementById('ayahInput').value || 21;
    const transId = document.getElementById('translationSelect').value;
    const reciterId = document.getElementById('reciterSelect').value || 7;
    const statusEl = document.getElementById('syncStatus');

    statusEl.textContent = `⏳ Soo jiidinaya Suurada ${surah}:${ayah} iyo Word-by-Word Timestamps...`;

    try {
        const url = `https://api.quran.com/api/v4/verses/by_key/${surah}:${ayah}?words=true&word_fields=text_uthmani,text_imlaei&translations=${transId !== 'none' ? transId : '131'}&audio=${reciterId}`;
        const res = await fetch(url);
        const data = await res.json();
        const verse = data.verse;

        const actualWords = verse.words.filter(w => w.char_type_name === 'word');
        state.words = actualWords.map((w, idx) => ({
            text: w.text_uthmani,
            start: idx * 1.5,
            end: (idx + 1) * 1.5
        }));

        state.surah = surah;
        state.ayah = ayah;
        state.ayahNumberArabic = toArabicDigits(ayah);

        if (transId === 'none') {
            state.translation = '';
        } else if (verse.translations && verse.translations.length > 0) {
            state.translation = verse.translations[0].text.replace(/<[^>]*>/g, '');
        }

        // Load audio & word segments if available
        const audioRes = await fetch(`https://api.quran.com/api/v4/recitations/${reciterId}/by_ayah/${surah}:${ayah}`);
        const audioData = await audioRes.json();
        if (audioData.audio_files && audioData.audio_files.length > 0) {
            const af = audioData.audio_files[0];
            const audioUrl = af.url.startsWith('http') ? af.url : `https://verses.quran.com/${af.url}`;
            ayahAudio.src = audioUrl;
            if (af.segments && af.segments.length > 0) {
                af.segments.forEach(seg => {
                    // seg format: [word_index_1_based, start_ms, end_ms]
                    const wIdx = seg[0] - 1;
                    if (state.words[wIdx]) {
                        state.words[wIdx].start = seg[1] / 1000;
                        state.words[wIdx].end = seg[2] / 1000;
                    }
                });
            }
        }

        state.activeWordIndex = Math.min(2, state.words.length - 1);
        renderWordTimeline();
        drawCanvas();
        statusEl.textContent = `✅ Si guul leh ayaa loo soo jiiday ${surah}:${ayah} (${state.words.length} erey oo Word-by-Word ah).`;
    } catch (err) {
        console.error(err);
        statusEl.textContent = `⚠️ Offline Mode: Waxaa lagu shaqeynayaa xogta kaydsan (59:21).`;
        renderWordTimeline();
        drawCanvas();
    }
}

// Render interactive word pills in timeline
function renderWordTimeline() {
    const container = document.getElementById('wordTimelineContainer');
    container.innerHTML = '';
    state.words.forEach((w, idx) => {
        const btn = document.createElement('button');
        const isActive = idx <= state.activeWordIndex;
        btn.className = `px-3 py-1.5 rounded-lg text-lg font-kfgqpc transition border ${
            idx === state.activeWordIndex
                ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold scale-105'
                : isActive
                ? 'bg-slate-800 text-white border-slate-600'
                : 'bg-slate-900 text-slate-500 border-slate-800'
        }`;
        btn.textContent = w.text;
        btn.onclick = () => {
            state.activeWordIndex = idx;
            updateTimeDisplay();
            renderWordTimeline();
            drawCanvas();
        };
        container.appendChild(btn);
    });
    updateTimeDisplay();
}

function updateTimeDisplay() {
    const el = document.getElementById('timeDisplay');
    el.textContent = `Active Word: ${state.activeWordIndex + 1} / ${state.words.length}`;
}

// Helper to convert hex color + alpha to rgba
function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

// Draw Frame on Canvas (Matches Reference Image Style!)
function drawCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. Draw Background Video or Subtle Studio Backdrop (unless Transparent Mode is ON)
    if (!state.transparentMode) {
        if (state.hasCustomVideo && bgVideo.readyState >= 2) {
            ctx.drawImage(bgVideo, 0, 0, canvas.width, canvas.height);
        } else {
            // Cinematic warm background placeholder similar to video frame
            const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
            bgGrad.addColorStop(0, '#332924');
            bgGrad.addColorStop(0.5, '#1e1b18');
            bgGrad.addColorStop(1, '#090a0c');
            ctx.fillStyle = bgGrad;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        }

        // 2. Draw Smooth Bottom Gradient Overlay (Exact style from user's image)
        const gradHeight = canvas.height * 0.55;
        const bottomGrad = ctx.createLinearGradient(0, canvas.height - gradHeight, 0, canvas.height);
        bottomGrad.addColorStop(0, hexToRgba(state.gradientColor, 0));
        bottomGrad.addColorStop(0.45, hexToRgba(state.gradientColor, state.gradientOpacity * 0.65));
        bottomGrad.addColorStop(1, hexToRgba(state.gradientColor, state.gradientOpacity));
        ctx.fillStyle = bottomGrad;
        ctx.fillRect(0, canvas.height - gradHeight, canvas.width, gradHeight);
    }

    // 3. Draw Word-by-Word Quranic Verse (Right-to-Left layout with active/inactive colors)
    ctx.save();
    ctx.font = `${state.arabicFontSize}px 'KFGQPC Uthmanic Script HAFS', 'Amiri Quran', serif`;
    ctx.textBaseline = 'middle';
    const spaceWidth = state.arabicFontSize * 0.32;

    // Measure all words + verse end ornament
    const verseEndSymbol = ` ﴿${state.ayahNumberArabic}﴾ `;
    const wordMetrics = state.words.map(w => ctx.measureText(w.text).width);
    const symbolWidth = ctx.measureText(verseEndSymbol).width;
    const totalWidth = wordMetrics.reduce((a, b) => a + b, 0) + (state.words.length * spaceWidth) + symbolWidth;

    // Start X from right edge of centered block
    let currentRightX = (canvas.width + totalWidth) / 2;
    const arabicY = canvas.height - 145;

    state.words.forEach((wordObj, idx) => {
        const wWidth = wordMetrics[idx];
        const wordCenterX = currentRightX - (wWidth / 2);

        // Determine if word is highlighted (cumulative like user's screenshot or pill box)
        const isHighlighted = idx <= state.activeWordIndex;
        const preset = document.getElementById('stylePreset').value;

        if (preset === 'emerald_box' && idx === state.activeWordIndex) {
            ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
            ctx.beginPath();
            ctx.roundRect(currentRightX - wWidth - 12, arabicY - state.arabicFontSize * 0.65, wWidth + 24, state.arabicFontSize * 1.3, 12);
            ctx.fill();
        }

        if (preset === 'gold_glow' && idx === state.activeWordIndex) {
            ctx.shadowColor = '#fbbf24';
            ctx.shadowBlur = 18;
            ctx.fillStyle = '#fde68a';
        } else {
            ctx.shadowBlur = 0;
            ctx.fillStyle = isHighlighted ? state.activeColor : state.inactiveColor;
        }

        ctx.textAlign = 'center';
        ctx.fillText(wordObj.text, wordCenterX, arabicY);
        currentRightX -= (wWidth + spaceWidth);
    });

    // Draw Ayah End Symbol ﴿٢١﴾
    ctx.shadowBlur = 0;
    ctx.fillStyle = state.activeWordIndex === state.words.length - 1 ? state.activeColor : state.inactiveColor;
    ctx.fillText(verseEndSymbol, currentRightX - (symbolWidth / 2), arabicY);
    ctx.restore();

    // 4. Draw Subtitle Translation Below (Matches Reference Image)
    if (state.translation) {
        ctx.save();
        ctx.font = `500 23px 'Inter', serif`;
        ctx.fillStyle = '#cbd5e1';
        ctx.textAlign = 'center';
        ctx.shadowColor = 'rgba(0,0,0,0.8)';
        ctx.shadowBlur = 6;
        ctx.fillText(state.translation, canvas.width / 2, canvas.height - 62);
        ctx.restore();
    }

    if (state.isPlaying) {
        requestAnimationFrame(syncLoop);
    }
}

function syncLoop() {
    if (!state.isPlaying) return;
    const currentTime = !ayahAudio.paused ? ayahAudio.currentTime : (bgVideo.currentTime || 0);
    const foundIdx = state.words.findIndex(w => currentTime >= w.start && currentTime <= w.end);
    if (foundIdx !== -1 && foundIdx !== state.activeWordIndex) {
        state.activeWordIndex = foundIdx;
        renderWordTimeline();
    }
    drawCanvas();
}

// Event Listeners
document.getElementById('btnFetchAyah').addEventListener('click', fetchAyahData);
document.getElementById('btnLoadRecitation').addEventListener('click', fetchAyahData);

document.getElementById('btnPrevWord').addEventListener('click', () => {
    state.activeWordIndex = Math.max(0, state.activeWordIndex - 1);
    renderWordTimeline();
    drawCanvas();
});

document.getElementById('btnNextWord').addEventListener('click', () => {
    state.activeWordIndex = Math.min(state.words.length - 1, state.activeWordIndex + 1);
    renderWordTimeline();
    drawCanvas();
});

document.getElementById('btnPlayPause').addEventListener('click', () => {
    if (state.isPlaying) {
        state.isPlaying = false;
        ayahAudio.pause();
        bgVideo.pause();
        document.getElementById('btnPlayPause').textContent = '▶️ Play Word-by-Word Sync';
    } else {
        state.isPlaying = true;
        document.getElementById('btnPlayPause').textContent = '⏸️ Pause Sync';
        if (ayahAudio.src) {
            ayahAudio.currentTime = 0;
            ayahAudio.play().catch(() => {});
        }
        if (state.hasCustomVideo) {
            bgVideo.currentTime = 0;
            bgVideo.play().catch(() => {});
        }
        // Fallback auto-step if no external audio playing
        if (!ayahAudio.src && !state.hasCustomVideo) {
            let step = 0;
            const interval = setInterval(() => {
                if (!state.isPlaying || step >= state.words.length) {
                    clearInterval(interval);
                    state.isPlaying = false;
                    document.getElementById('btnPlayPause').textContent = '▶️ Play Word-by-Word Sync';
                    return;
                }
                state.activeWordIndex = step++;
                renderWordTimeline();
                drawCanvas();
            }, 900);
        } else {
            requestAnimationFrame(syncLoop);
        }
    }
});

// Style Controls Listeners
['activeColor', 'inactiveColor', 'gradientColor'].forEach(id => {
    document.getElementById(id).addEventListener('input', (e) => {
        state[id] = e.target.value;
        drawCanvas();
    });
});

document.getElementById('gradientOpacity').addEventListener('input', (e) => {
    state.gradientOpacity = parseInt(e.target.value, 10) / 100;
    document.getElementById('gradOpacityVal').textContent = `${e.target.value}%`;
    drawCanvas();
});

document.getElementById('arabicFontSize').addEventListener('input', (e) => {
    state.arabicFontSize = parseInt(e.target.value, 10);
    document.getElementById('fontSizeVal').textContent = `${e.target.value}px`;
    drawCanvas();
});

document.getElementById('transparentBgToggle').addEventListener('change', (e) => {
    state.transparentMode = e.target.checked;
    drawCanvas();
});

document.getElementById('stylePreset').addEventListener('change', (e) => {
    const val = e.target.value;
    if (val === 'image_ref') {
        state.activeColor = '#ffffff';
        state.inactiveColor = '#64748b';
        state.transparentMode = false;
    } else if (val === 'minimal_alpha') {
        state.transparentMode = true;
        document.getElementById('transparentBgToggle').checked = true;
    }
    drawCanvas();
});

// Upload Custom Video/Audio
document.getElementById('mediaUpload').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    if (file.type.startsWith('video/')) {
        bgVideo.src = url;
        state.hasCustomVideo = true;
        bgVideo.onloadeddata = () => drawCanvas();
    } else {
        ayahAudio.src = url;
    }
    document.getElementById('syncStatus').textContent = `📁 Faylka la soo galiyay: ${file.name}`;
});

// Export PNG (with Transparency support)
document.getElementById('btnExportPNG').addEventListener('click', () => {
    const prevTrans = state.transparentMode;
    state.transparentMode = true;
    drawCanvas();
    const link = document.createElement('a');
    link.download = `QuranCaption_${state.surah}_${state.ayah}_Transparent.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    state.transparentMode = prevTrans;
    drawCanvas();
});

// Export Video (MP4 / MOV WebM Alpha via MediaRecorder)
function exportVideo(format) {
    const stream = canvas.captureStream(30);
    const mimeType = format === 'mov' && MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';
    const recorder = new MediaRecorder(stream, { mimeType });
    const chunks = [];
    recorder.ondataavailable = e => chunks.push(e.data);
    recorder.onstop = () => {
        const blob = new Blob(chunks, { type: mimeType });
        const link = document.createElement('a');
        link.download = `QuranCaption_${state.surah}_${state.ayah}.${format === 'mov' ? 'webm' : 'mp4'}`;
        link.href = URL.createObjectURL(blob);
        link.click();
    };
    recorder.start();
    document.getElementById('btnPlayPause').click();
    setTimeout(() => {
        if (recorder.state === 'recording') recorder.stop();
    }, state.words.length * 1000 + 500);
}

document.getElementById('btnExportMP4').addEventListener('click', () => exportVideo('mp4'));
document.getElementById('btnExportMOV').addEventListener('click', () => {
    state.transparentMode = true;
    document.getElementById('transparentBgToggle').checked = true;
    exportVideo('mov');
});

// Initialize Studio
initSurahs();
renderWordTimeline();
document.fonts.ready.then(() => drawCanvas());
drawCanvas();
