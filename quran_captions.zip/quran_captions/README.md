# Quran Captions (Flutter)

Word-by-word Quran caption maker: Quran.com API, multi-reciter / multi-riwaya,
custom colors, gradient/transparent background, custom fonts, MP4 / MOV(alpha) / PNG export.

## GitHub → APK (Somali)

1. Samee account GitHub → **New repository** (`quran-captions`).
2. Unzip file-kan. Fur repo-ga → **Add file → Upload files** → soo jiid FAYLASHA MAQNAAN (ma aha folder-ka zip-ka laftiisa): `lib/`, `.github/`, `pubspec.yaml`, `.gitignore`, `README.md`. Hubi in `.github/workflows/build.yml` la geeyay → **Commit**.
3. Tag **Actions** tab → "Build APK" wuu ordayaa si toos ah (ama **Run workflow**). 8–15 daqiiqo.
4. Marka uu green noqdo → gal run-ka → hoose **Artifacts** → soo dejiso `quran-captions-apk` → unzip → `app-release.apk` → ku rakib taleefanka.
