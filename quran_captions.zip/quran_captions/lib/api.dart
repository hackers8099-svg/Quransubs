import 'dart:convert';
import 'package:http/http.dart' as http;

const _base = 'https://api.quran.com/api/v4';

Future<Map<String, dynamic>> _get(String path) async {
  final r = await http.get(Uri.parse('$_base$path'));
  if (r.statusCode != 200) {
    throw Exception('API ${r.statusCode} -> $path');
  }
  return jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
}

String _s(dynamic v) {
  if (v == null) return '';
  if (v is Map) return (v['name'] ?? '').toString();
  return v.toString();
}

String _strip(dynamic html) =>
    (html ?? '').toString().replaceAll(RegExp(r'<sup[^>]*>.*?</sup>'), '').replaceAll(RegExp(r'<[^>]+>'), '').trim();

class Chapter {
  final int id;
  final String name;
  final String arabic;
  final int verses;
  Chapter(this.id, this.name, this.arabic, this.verses);
}

class Reciter {
  final int id;
  final String name;
  final String qirat;
  final String style;
  Reciter(this.id, this.name, this.qirat, this.style);
  String get label => '$name${qirat.isNotEmpty ? ' · $qirat' : ''}${style.isNotEmpty ? ' · $style' : ''}';
}

class Translation {
  final int id;
  final String name;
  final String lang;
  Translation(this.id, this.name, this.lang);
}

class WordT {
  final int pos;
  final String text;
  int start = 0;
  int end = 0;
  WordT(this.pos, this.text);
}

class AyahT {
  final String key;
  final int num;
  final List<WordT> words;
  final String translation;
  int start = 0;
  int end = 0;
  AyahT(this.key, this.num, this.words, this.translation);

  AyahT clone() {
    final a = AyahT(key, num, words.map((w) => WordT(w.pos, w.text)).toList(), translation);
    a.start = start;
    a.end = end;
    return a;
  }
}

class ClipData {
  final String audioUrl;
  final int clipStart; // ms inside chapter audio
  final int clipDur; // ms
  final List<AyahT> ayahs;
  final bool synced; // true = real word segments from API
  final Reciter reciter;
  ClipData(this.audioUrl, this.clipStart, this.clipDur, this.ayahs, this.synced, this.reciter);
}

class FrameState {
  final int ayah;
  final int active; // -1 = nothing yet, -2 = whole ayah
  final int ms;
  FrameState(this.ayah, this.active, this.ms);
}

Future<List<Chapter>> fetchChapters() async {
  final j = await _get('/chapters?language=en');
  return (j['chapters'] as List)
      .map((e) => Chapter(e['id'] as int, e['name_simple'].toString(), e['name_arabic'].toString(), e['verses_count'] as int))
      .toList();
}

Future<List<Reciter>> fetchReciters() async {
  final j = await _get('/resources/chapter_reciters');
  return (j['reciters'] as List)
      .map((e) => Reciter(e['id'] as int, _s(e['name']), _s(e['qirat']), _s(e['style'])))
      .toList();
}

Future<List<Translation>> fetchTranslations() async {
  final j = await _get('/resources/translations');
  final l = (j['translations'] as List)
      .map((e) => Translation(e['id'] as int, e['name'].toString(), (e['language_name'] ?? '').toString()))
      .toList();
  int rank(Translation t) => t.lang.toLowerCase() == 'english' ? 0 : (t.lang.toLowerCase() == 'somali' ? 1 : 2);
  l.sort((a, b) => rank(a).compareTo(rank(b)));
  return l;
}

Future<List<AyahT>> fetchAyahs(int chapter, int from, int to, int? translationId) async {
  final out = <AyahT>[];
  var page = 1;
  while (true) {
    final tr = translationId != null ? '&translations=$translationId' : '';
    final j = await _get('/verses/by_chapter/$chapter?words=true&word_fields=text_uthmani&per_page=50&page=$page$tr');
    for (final v in (j['verses'] as List)) {
      final n = v['verse_number'] as int;
      if (n < from || n > to) continue;
      final words = <WordT>[];
      for (final w in (v['words'] as List)) {
        if (w['char_type_name'] == 'word') {
          words.add(WordT(w['position'] as int, (w['text_uthmani'] ?? w['text'] ?? '').toString()));
        }
      }
      var t = '';
      final trs = v['translations'];
      if (trs is List && trs.isNotEmpty) t = _strip(trs.first['text']);
      out.add(AyahT(v['verse_key'].toString(), n, words, t));
    }
    final next = (j['pagination'] as Map?)?['next_page'];
    if (next == null || (out.isNotEmpty && out.last.num >= to)) break;
    page = next as int;
  }
  return out;
}

/// Gets chapter audio + per-verse / per-word timestamps from Quran.com.
/// If a reciter has no word segments, word timing is estimated by letter count.
Future<ClipData> alignClip(List<AyahT> source, int chapter, Reciter r) async {
  final ayahs = source.map((a) => a.clone()).toList();
  final j = await _get('/chapter_recitations/${r.id}/$chapter?segments=true');
  final file = j['audio_file'] as Map<String, dynamic>;
  var url = file['audio_url'].toString();
  if (url.startsWith('//')) url = 'https:$url';
  final ts = (file['timestamps'] as List?) ?? const [];
  if (ts.isEmpty) throw Exception('No verse timing for ${r.name}');
  final byKey = <String, Map<String, dynamic>>{
    for (final t in ts) t['verse_key'].toString(): (t as Map).cast<String, dynamic>(),
  };
  final first = byKey[ayahs.first.key];
  final last = byKey[ayahs.last.key];
  if (first == null || last == null) throw Exception('Verse timing missing');
  final clipStart = (first['timestamp_from'] as num).toInt();
  final clipEnd = (last['timestamp_to'] as num).toInt();
  var synced = true;

  for (var i = 0; i < ayahs.length; i++) {
    final a = ayahs[i];
    final t = byKey[a.key]!;
    final from = (t['timestamp_from'] as num).toInt();
    final to = (t['timestamp_to'] as num).toInt();
    final nextFrom = i + 1 < ayahs.length ? (byKey[ayahs[i + 1].key]!['timestamp_from'] as num).toInt() : to;
    a.start = from - clipStart;
    a.end = nextFrom - clipStart;

    final segs = <int, List<int>>{};
    for (final s in ((t['segments'] as List?) ?? const [])) {
      final l = (s as List).map((e) => (e as num).toInt()).toList();
      if (l.length >= 3) segs[l[l.length - 3]] = [l[l.length - 2], l.last];
    }
    final ok = a.words.isNotEmpty && a.words.every((w) => segs.containsKey(w.pos));
    if (ok) {
      for (final w in a.words) {
        w.start = segs[w.pos]![0] - clipStart;
        w.end = segs[w.pos]![1] - clipStart;
      }
    } else {
      synced = false;
      final total = a.words.fold<int>(0, (s, w) => s + w.text.length + 1);
      var acc = 0;
      for (final w in a.words) {
        w.start = a.start + ((a.end - a.start) * acc / total).round();
        acc += w.text.length + 1;
        w.end = a.start + ((a.end - a.start) * acc / total).round();
      }
    }
  }
  return ClipData(url, clipStart, clipEnd - clipStart, ayahs, synced, r);
}

List<FrameState> buildTimeline(ClipData c, int mode) {
  final out = <FrameState>[];
  for (var ai = 0; ai < c.ayahs.length; ai++) {
    final a = c.ayahs[ai];
    final dur = a.end - a.start;
    if (mode == 2 || a.words.isEmpty) {
      out.add(FrameState(ai, -2, dur < 40 ? 40 : dur));
      continue;
    }
    final lead = a.words.first.start - a.start;
    if (lead > 40) out.add(FrameState(ai, -1, lead));
    for (var i = 0; i < a.words.length; i++) {
      final st = a.words[i].start < a.start ? a.start : a.words[i].start;
      final en = i + 1 < a.words.length ? a.words[i + 1].start : a.end;
      final d = en - st;
      out.add(FrameState(ai, i, d < 40 ? 40 : d));
    }
  }
  return out;
}
