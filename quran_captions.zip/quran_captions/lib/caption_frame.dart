import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'api.dart';
import 'style.dart';

TextStyle arabicTextStyle(String font, List<String> custom, double size, Color color, {List<Shadow>? shadows}) {
  if (custom.contains(font)) {
    return TextStyle(fontFamily: font, fontSize: size, color: color, height: 1.9, shadows: shadows);
  }
  return GoogleFonts.getFont(font, fontSize: size, color: color, height: 1.9, shadows: shadows);
}

String arabicDigits(int n) {
  const d = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return n.toString().split('').map((c) => d[int.parse(c)]).join();
}

class CaptionFrame extends StatelessWidget {
  const CaptionFrame({
    super.key,
    required this.style,
    required this.ayah,
    required this.active,
    required this.size,
    required this.customFonts,
    required this.transparent,
  });

  final CapStyle style;
  final AyahT? ayah;
  final int active;
  final Size size;
  final List<String> customFonts;
  final bool transparent;

  @override
  Widget build(BuildContext context) {
    final a = ayah;
    final k = min(size.width, size.height) / 540;
    final area = size.width * size.height;
    BoxDecoration? deco;
    if (!transparent) {
      if (style.gradient) {
        final r = style.angle * pi / 180;
        deco = BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment(-sin(r), -cos(r)),
            end: Alignment(sin(r), cos(r)),
            colors: [style.bg1, style.bg2],
          ),
        );
      } else {
        deco = BoxDecoration(color: style.bg1);
      }
    }

    Widget content = const SizedBox.shrink();
    if (a != null) {
      final hasTr = style.showTrans && a.translation.isNotEmpty;
      final chars = a.words.fold<int>(0, (s, w) => s + w.text.length + 1) + 6;
      final fit = sqrt((hasTr ? 0.30 : 0.5) * area / (chars * 0.55 * 1.9));
      final fs = min(style.arabicSize * k, fit);
      final shadows = transparent ? [const Shadow(blurRadius: 8, color: Colors.black87)] : null;

      final children = <Widget>[];
      for (var i = 0; i < a.words.length; i++) {
        final visible = !(style.mode == 0 && active != -2 && i > active);
        final isActive = style.mode != 2 && i == active;
        children.add(Opacity(
          opacity: visible ? 1 : 0,
          child: Text(a.words[i].text,
              style: arabicTextStyle(style.font, customFonts, fs, isActive ? style.active : style.text, shadows: shadows)),
        ));
      }
      final endVisible = style.mode != 0 || active == -2 || active >= a.words.length - 1;
      children.add(Opacity(
        opacity: endVisible ? 1 : 0,
        child: Text('﴿${arabicDigits(a.num)}﴾',
            style: arabicTextStyle(style.font, customFonts, fs * 0.8, style.active, shadows: shadows)),
      ));

      double ts = style.transSize * k;
      if (hasTr) {
        ts = min(ts, sqrt(0.18 * area / (a.translation.length * 0.55 * 1.5)));
      }

      content = Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Directionality(
            textDirection: TextDirection.rtl,
            child: Wrap(
              alignment: WrapAlignment.center,
              crossAxisAlignment: WrapCrossAlignment.center,
              spacing: fs * 0.28,
              children: children,
            ),
          ),
          if (hasTr) ...[
            SizedBox(height: 10 * k),
            Text(
              a.translation,
              textAlign: TextAlign.center,
              textDirection: TextDirection.ltr,
              style: TextStyle(
                fontSize: ts,
                color: style.text.withOpacity(0.85),
                height: 1.35,
                shadows: shadows,
              ),
            ),
          ],
        ],
      );
    }

    return Container(
      width: size.width,
      height: size.height,
      decoration: deco,
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.07, vertical: size.height * 0.06),
      child: Center(child: content),
    );
  }
}
