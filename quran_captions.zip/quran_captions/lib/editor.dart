import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:share_plus/share_plus.dart';
import 'api.dart';
import 'caption_frame.dart';
import 'exporter.dart';
import 'style.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key});
  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final player = AudioPlayer();
  final boundaryKey = GlobalKey();
  StreamSubscription? _sub;

  List<Chapter> chapters = [];
  List<Reciter> reciters = [];
  List<Translation> translations = [];
  Chapter? chapter;
  Reciter? reciter; // null = Auto
  Translation? translation;
  String qirat = 'All';
  final fromC = TextEditingController(text: '1');
  final toC = TextEditingController(text: '3');

  CapStyle style = presets.values.first();
  List<String> customFonts = [];
  int aspect = 0;
  bool hq = true;

  ClipData? clip;
  List<FrameState> timeline = [];
  List<int> starts = [];
  int cur = 0;
  bool loading = false;
  bool exporting = false;
  String? exportKind;
  double progress = 0;
  String status = '';

  @override
  void initState() {
    super.initState();
    _init();
    _sub = player.positionStream.listen((p) {
      if (clip == null || exporting || timeline.isEmpty) return;
      final ms = p.inMilliseconds;
      var idx = 0;
      for (var i = 0; i < starts.length; i++) {
        if (starts[i] <= ms) {
          idx = i;
        } else {
          break;
        }
      }
      if (idx != cur && mounted) setState(() => cur = idx);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    player.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    try {
      final r = await Future.wait([fetchChapters(), fetchReciters(), fetchTranslations()]);
      chapters = r[0] as List<Chapter>;
      reciters = r[1] as List<Reciter>;
      translations = r[2] as List<Translation>;
      chapter = chapters.first;
      translation = translations.firstWhere((t) => t.id == 20, orElse: () => translations.first);
      if (mounted) setState(() {});
    } catch (e) {
      _msg('Network error: $e');
    }
  }

  void _msg(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  List<Reciter> get visibleReciters =>
      reciters.where((r) => qirat == 'All' || r.qirat == qirat).toList();

  List<String> get qiratList {
    final s = reciters.map((r) => r.qirat).where((e) => e.isNotEmpty).toSet().toList()..sort();
    return ['All', ...s];
  }

  bool get _alpha => style.transparent && !(exporting && exportKind == 'mp4');

  Future<void> load() async {
    if (chapter == null || loading) return;
    final from = int.tryParse(fromC.text) ?? 1;
    var to = int.tryParse(toC.text) ?? from;
    if (to > chapter!.verses) to = chapter!.verses;
    if (to - from > 14) to = from + 14; // keep clips short & fast
    setState(() {
      loading = true;
      status = 'Loading...';
    });
    try {
      await player.stop();
      final ayahs = await fetchAyahs(chapter!.id, from, to, translation?.id);
      if (ayahs.isEmpty) throw Exception('No ayahs in this range');
      final cands = reciter != null ? [reciter!] : visibleReciters.take(12).toList();
      ClipData? best;
      String err = '';
      for (final r in cands) {
        try {
          final c = await alignClip(ayahs, chapter!.id, r);
          best ??= c;
          if (c.synced) {
            best = c;
            break;
          }
        } catch (e) {
          err = e.toString();
        }
      }
      if (best == null) throw Exception(err.isEmpty ? 'No reciter available' : err);
      clip = best;
      timeline = buildTimeline(best, style.mode);
      starts = _calcStarts();
      cur = 0;
      await player.setAudioSource(ClippingAudioSource(
        child: AudioSource.uri(Uri.parse(best.audioUrl)),
        start: Duration(milliseconds: best.clipStart),
        end: Duration(milliseconds: best.clipStart + best.clipDur),
      ));
      status = '${best.reciter.label} — ${best.synced ? 'word sync ✔' : 'estimated word timing'}';
    } catch (e) {
      status = '';
      _msg('$e');
    }
    if (mounted) setState(() => loading = false);
  }

  List<int> _calcStarts() {
    final l = <int>[];
    var t = 0;
    for (final f in timeline) {
      l.add(t);
      t += f.ms;
    }
    return l;
  }

  void rebuildTimeline() {
    if (clip == null) return;
    timeline = buildTimeline(clip!, style.mode);
    starts = _calcStarts();
    cur = 0;
  }

  Future<void> export(String kind) async {
    final c = clip;
    if (c == null || exporting) return;
    await player.pause();
    setState(() {
      exporting = true;
      exportKind = kind;
      progress = 0;
      status = 'Rendering...';
    });
    try {
      final path = await exportClip(
        boundaryKey: boundaryKey,
        timeline: timeline,
        clip: c,
        kind: kind,
        pixelRatio: hq ? 2.0 : 1.0,
        setFrame: (i) async {
          setState(() => cur = i);
          await GoogleFonts.pendingFonts();
          await WidgetsBinding.instance.endOfFrame;
          await Future.delayed(const Duration(milliseconds: 20));
        },
        onProgress: (p, s) {
          if (mounted) setState(() {
                progress = p;
                status = s;
              });
        },
      );
      await Share.shareXFiles([XFile(path)]);
    } catch (e) {
      _msg('Export error: $e');
    }
    if (mounted) setState(() {
          exporting = false;
          exportKind = null;
          status = 'Done';
        });
  }

  Future<void> exportPng() async {
    if (clip == null) return;
    await GoogleFonts.pendingFonts();
    final bytes = await captureBoundary(boundaryKey, hq ? 2.0 : 1.0);
    final path = await savePng(bytes);
    await Share.shareXFiles([XFile(path)]);
  }

  Future<void> importFont() async {
    final res = await FilePicker.platform.pickFiles(withData: true);
    if (res == null || res.files.single.bytes == null) return;
    final f = res.files.single;
    final name = f.name.replaceAll(RegExp(r'\.(ttf|otf)$', caseSensitive: false), '');
    final loader = FontLoader(name)..addFont(Future.value(ByteData.sublistView(f.bytes!)));
    await loader.load();
    setState(() {
      customFonts.add(name);
      style.font = name;
    });
    _msg('Font loaded: $name');
  }

  Future<void> pickColor(String label, Color c, ValueChanged<Color> on) async {
    var tmp = c;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(label),
        content: SingleChildScrollView(
          child: ColorPicker(pickerColor: c, onColorChanged: (v) => tmp = v, enableAlpha: false, labelTypes: const []),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
    setState(() => on(tmp));
  }

  Widget colorTile(String label, Color c, ValueChanged<Color> on) => ActionChip(
        avatar: CircleAvatar(backgroundColor: c, radius: 9),
        label: Text(label),
        onPressed: () => pickColor(label, c, on),
      );

  Widget section(String t) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 6),
        child: Text(t, style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Colors.tealAccent)),
      );

  Widget preview() {
    final sz = aspects[aspect].size;
    final f = timeline.isNotEmpty ? timeline[cur.clamp(0, timeline.length - 1)] : null;
    final ay = (f != null && clip != null) ? clip!.ayahs[f.ayah] : null;
    return Container(
      color: Colors.grey.shade800,
      child: AspectRatio(
        aspectRatio: sz.width / sz.height,
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: sz.width,
            height: sz.height,
            child: RepaintBoundary(
              key: boundaryKey,
              child: CaptionFrame(
                style: style,
                ayah: ay,
                active: f?.active ?? -2,
                size: sz,
                customFonts: customFonts,
                transparent: _alpha,
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final fonts = [...fontChoices, ...customFonts];
    return Scaffold(
      appBar: AppBar(title: const Text('Quran Captions')),
      body: chapters.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(12),
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.38,
                  child: Center(child: preview()),
                ),
                if (timeline.isNotEmpty) ...[
                  Row(children: [
                    StreamBuilder<bool>(
                      stream: player.playingStream,
                      builder: (_, s) => IconButton.filled(
                        icon: Icon((s.data ?? false) ? Icons.pause : Icons.play_arrow),
                        onPressed: exporting
                            ? null
                            : () async {
                                if (player.playing) {
                                  await player.pause();
                                } else {
                                  if (player.processingState == ProcessingState.completed) {
                                    await player.seek(Duration.zero);
                                  }
                                  player.play();
                                }
                              },
                      ),
                    ),
                    Expanded(
                      child: Slider(
                        value: cur.toDouble().clamp(0, (timeline.length - 1).toDouble()),
                        max: (timeline.length - 1).toDouble().clamp(1, 100000),
                        onChanged: exporting
                            ? null
                            : (v) {
                                setState(() => cur = v.round());
                                player.seek(Duration(milliseconds: starts[cur]));
                              },
                      ),
                    ),
                  ]),
                ],
                if (exporting) LinearProgressIndicator(value: progress),
                if (status.isNotEmpty) Text(status, style: const TextStyle(fontSize: 12)),

                section('1 · Surah & ayahs'),
                DropdownButton<Chapter>(
                  isExpanded: true,
                  value: chapter,
                  items: chapters
                      .map((c) => DropdownMenuItem(value: c, child: Text('${c.id}. ${c.name}  ${c.arabic}  (${c.verses})')))
                      .toList(),
                  onChanged: (c) => setState(() {
                    chapter = c;
                    fromC.text = '1';
                    toC.text = '${(c!.verses).clamp(1, 3)}';
                  }),
                ),
                Row(children: [
                  Expanded(
                    child: TextField(
                      controller: fromC,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: const InputDecoration(labelText: 'From ayah'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: toC,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: const InputDecoration(labelText: 'To ayah (max 15)'),
                    ),
                  ),
                ]),

                section('2 · Riwaya / Qari'),
                Wrap(
                  spacing: 6,
                  children: qiratList
                      .map((q) => ChoiceChip(
                            label: Text(q),
                            selected: qirat == q,
                            onSelected: (_) => setState(() {
                              qirat = q;
                              reciter = null;
                            }),
                          ))
                      .toList(),
                ),
                DropdownButton<Reciter?>(
                  isExpanded: true,
                  value: reciter,
                  items: [
                    const DropdownMenuItem<Reciter?>(value: null, child: Text('Auto (best word sync)')),
                    ...visibleReciters.map((r) => DropdownMenuItem<Reciter?>(value: r, child: Text(r.label, overflow: TextOverflow.ellipsis))),
                  ],
                  onChanged: (r) => setState(() => reciter = r),
                ),

                section('3 · Translation'),
                DropdownButton<Translation?>(
                  isExpanded: true,
                  value: translation,
                  items: [
                    const DropdownMenuItem<Translation?>(value: null, child: Text('None')),
                    ...translations.map((t) => DropdownMenuItem<Translation?>(
                        value: t, child: Text('${t.lang} · ${t.name}', overflow: TextOverflow.ellipsis))),
                  ],
                  onChanged: (t) => setState(() {
                    translation = t;
                    if (t == null) style.showTrans = false;
                  }),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: loading ? null : load,
                  icon: loading
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.download),
                  label: const Text('Load & sync'),
                ),

                section('4 · Style'),
                Wrap(
                  spacing: 6,
                  children: presets.entries
                      .map((e) => ActionChip(
                            label: Text(e.key),
                            onPressed: () => setState(() {
                              final keepFont = customFonts.contains(style.font) ? style.font : null;
                              style = e.value();
                              if (keepFont != null) style.font = keepFont;
                              rebuildTimeline();
                            }),
                          ))
                      .toList(),
                ),
                const SizedBox(height: 8),
                Wrap(spacing: 6, children: [
                  colorTile('Text', style.text, (c) => style.text = c),
                  colorTile('Active word', style.active, (c) => style.active = c),
                  colorTile('Background 1', style.bg1, (c) => style.bg1 = c),
                  if (style.gradient) colorTile('Background 2', style.bg2, (c) => style.bg2 = c),
                ]),
                SwitchListTile(
                  dense: true,
                  title: const Text('Gradient background'),
                  value: style.gradient,
                  onChanged: (v) => setState(() => style.gradient = v),
                ),
                if (style.gradient)
                  Row(children: [
                    const Text('Angle'),
                    Expanded(
                      child: Slider(
                        value: style.angle,
                        min: 0,
                        max: 360,
                        onChanged: (v) => setState(() => style.angle = v),
                      ),
                    ),
                  ]),
                SwitchListTile(
                  dense: true,
                  title: const Text('Transparent background (for .mov alpha / PNG)'),
                  value: style.transparent,
                  onChanged: (v) => setState(() => style.transparent = v),
                ),
                SwitchListTile(
                  dense: true,
                  title: const Text('Show translation'),
                  value: style.showTrans,
                  onChanged: (v) => setState(() => style.showTrans = v),
                ),
                Row(children: [
                  const Text('Arabic size'),
                  Expanded(
                    child: Slider(
                      value: style.arabicSize,
                      min: 24,
                      max: 90,
                      onChanged: (v) => setState(() => style.arabicSize = v),
                    ),
                  ),
                ]),
                Row(children: [
                  const Text('Translation size'),
                  Expanded(
                    child: Slider(
                      value: style.transSize,
                      min: 12,
                      max: 40,
                      onChanged: (v) => setState(() => style.transSize = v),
                    ),
                  ),
                ]),
                DropdownButton<int>(
                  isExpanded: true,
                  value: style.mode,
                  items: const [
                    DropdownMenuItem(value: 0, child: Text('Word by word (reveal)')),
                    DropdownMenuItem(value: 1, child: Text('Word highlight')),
                    DropdownMenuItem(value: 2, child: Text('Full ayah (no word sync)')),
                  ],
                  onChanged: (v) => setState(() {
                    style.mode = v!;
                    rebuildTimeline();
                  }),
                ),
                DropdownButton<String>(
                  isExpanded: true,
                  value: fonts.contains(style.font) ? style.font : fonts.first,
                  items: fonts.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
                  onChanged: (v) => setState(() => style.font = v!),
                ),
                OutlinedButton.icon(
                  onPressed: importFont,
                  icon: const Icon(Icons.font_download),
                  label: const Text('Import font (.ttf/.otf) e.g. KFGQPC / King Fahd'),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  children: List.generate(
                    aspects.length,
                    (i) => ChoiceChip(
                      label: Text(aspects[i].name),
                      selected: aspect == i,
                      onSelected: (_) => setState(() => aspect = i),
                    ),
                  ),
                ),
                SwitchListTile(
                  dense: true,
                  title: const Text('High quality (1080p)'),
                  value: hq,
                  onChanged: (v) => setState(() => hq = v),
                ),

                section('5 · Export'),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  FilledButton.icon(
                    onPressed: (clip == null || exporting) ? null : () => export('mp4'),
                    icon: const Icon(Icons.movie),
                    label: const Text('MP4'),
                  ),
                  FilledButton.tonalIcon(
                    onPressed: (clip == null || exporting) ? null : () => export('mov'),
                    icon: const Icon(Icons.layers),
                    label: const Text('MOV (alpha)'),
                  ),
                  FilledButton.tonalIcon(
                    onPressed: (clip == null || exporting) ? null : exportPng,
                    icon: const Icon(Icons.image),
                    label: const Text('PNG (frame)'),
                  ),
                ]),
                const SizedBox(height: 40),
              ],
            ),
    );
  }
}
