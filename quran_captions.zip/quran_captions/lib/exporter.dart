import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'api.dart';

Future<Uint8List> captureBoundary(GlobalKey key, double pixelRatio) async {
  final ro = key.currentContext!.findRenderObject() as RenderRepaintBoundary;
  final img = await ro.toImage(pixelRatio: pixelRatio);
  final bd = await img.toByteData(format: ui.ImageByteFormat.png);
  return bd!.buffer.asUint8List();
}

Future<String> savePng(Uint8List bytes) async {
  final tmp = await getTemporaryDirectory();
  final f = File('${tmp.path}/quran_${DateTime.now().millisecondsSinceEpoch}.png');
  await f.writeAsBytes(bytes);
  return f.path;
}

/// kind: 'mp4' | 'mov'  (mov = transparent PNG codec + audio)
/// One PNG is rendered per caption state (not per video frame) and
/// ffmpeg's concat demuxer turns them into a video with exact timing.
Future<String> exportClip({
  required GlobalKey boundaryKey,
  required List<FrameState> timeline,
  required ClipData clip,
  required String kind,
  required double pixelRatio,
  required Future<void> Function(int index) setFrame,
  void Function(double, String)? onProgress,
}) async {
  final tmp = await getTemporaryDirectory();
  final stamp = DateTime.now().millisecondsSinceEpoch;
  final dir = Directory('${tmp.path}/cap_$stamp')..createSync(recursive: true);

  final list = StringBuffer('ffconcat version 1.0\n');
  for (var i = 0; i < timeline.length; i++) {
    await setFrame(i);
    final bytes = await captureBoundary(boundaryKey, pixelRatio);
    await File('${dir.path}/f$i.png').writeAsBytes(bytes);
    list.writeln("file 'f$i.png'");
    list.writeln('duration ${(timeline[i].ms / 1000).toStringAsFixed(3)}');
    onProgress?.call(0.7 * (i + 1) / timeline.length, 'Frame ${i + 1}/${timeline.length}');
  }
  list.writeln("file 'f${timeline.length - 1}.png'");
  await File('${dir.path}/list.txt').writeAsString(list.toString());

  onProgress?.call(0.72, 'Downloading audio...');
  final ar = await http.get(Uri.parse(clip.audioUrl));
  if (ar.statusCode != 200) throw Exception('Audio download failed (${ar.statusCode})');
  final audio = File('${dir.path}/audio.mp3')..writeAsBytesSync(ar.bodyBytes);

  final ss = (clip.clipStart / 1000).toStringAsFixed(3);
  final t = (clip.clipDur / 1000).toStringAsFixed(3);
  final out = '${tmp.path}/quran_$stamp.${kind == 'mov' ? 'mov' : 'mp4'}';
  final inputs = '-f concat -safe 0 -i "${dir.path}/list.txt" -ss $ss -t $t -i "${audio.path}"';

  onProgress?.call(0.78, 'Encoding...');
  Future<bool> run(String cmd) async {
    final s = await FFmpegKit.execute(cmd);
    return ReturnCode.isSuccess(await s.getReturnCode());
  }

  var ok = false;
  if (kind == 'mov') {
    ok = await run('-y $inputs -vf "fps=30" -pix_fmt rgba -c:v png -c:a aac -b:a 192k -shortest "$out"');
  } else {
    ok = await run(
        '-y $inputs -vf "fps=30,format=yuv420p" -c:v libx264 -preset veryfast -crf 20 -c:a aac -b:a 192k -shortest "$out"');
    if (!ok) {
      ok = await run(
          '-y $inputs -vf "fps=30,format=yuv420p" -c:v mpeg4 -q:v 3 -c:a aac -b:a 192k -shortest "$out"');
    }
  }
  try {
    dir.deleteSync(recursive: true);
  } catch (_) {}
  if (!ok) throw Exception('FFmpeg failed');
  onProgress?.call(1, 'Done');
  return out;
}
