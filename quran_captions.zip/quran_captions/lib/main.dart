import 'package:flutter/material.dart';
import 'editor.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const QuranCaptionsApp());
}

class QuranCaptionsApp extends StatelessWidget {
  const QuranCaptionsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quran Captions',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF1B7F5C),
      ),
      home: const EditorScreen(),
    );
  }
}
