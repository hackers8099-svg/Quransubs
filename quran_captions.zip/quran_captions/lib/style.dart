import 'package:flutter/material.dart';

/// Caption modes
/// 0 = word-by-word reveal, 1 = all visible + active word highlighted, 2 = full ayah (no word sync)
class CapStyle {
  String font;
  double arabicSize;
  double transSize;
  Color text;
  Color active;
  Color bg1;
  Color bg2;
  bool gradient;
  bool transparent;
  bool showTrans;
  double angle; // degrees
  int mode;

  CapStyle({
    this.font = 'Amiri Quran',
    this.arabicSize = 48,
    this.transSize = 20,
    this.text = Colors.white,
    this.active = const Color(0xFFFFD54F),
    this.bg1 = const Color(0xFF0B3D2E),
    this.bg2 = const Color(0xFF021B14),
    this.gradient = true,
    this.transparent = false,
    this.showTrans = true,
    this.angle = 180,
    this.mode = 0,
  });

  CapStyle copy() => CapStyle(
        font: font,
        arabicSize: arabicSize,
        transSize: transSize,
        text: text,
        active: active,
        bg1: bg1,
        bg2: bg2,
        gradient: gradient,
        transparent: transparent,
        showTrans: showTrans,
        angle: angle,
        mode: mode,
      );
}

final Map<String, CapStyle Function()> presets = {
  'Emerald': () => CapStyle(),
  'Midnight Gold': () => CapStyle(
        font: 'Scheherazade New',
        text: const Color(0xFFF5F5F5),
        active: const Color(0xFFFFC107),
        bg1: const Color(0xFF16213E),
        bg2: const Color(0xFF0F0F1A),
      ),
  'Sunset': () => CapStyle(
        font: 'Noto Naskh Arabic',
        text: Colors.white,
        active: const Color(0xFF212121),
        bg1: const Color(0xFFFF7E5F),
        bg2: const Color(0xFFFEB47B),
        angle: 135,
        mode: 1,
      ),
  'Minimal Dark': () => CapStyle(
        font: 'Amiri Quran',
        text: const Color(0xFFE0E0E0),
        active: const Color(0xFF4DD0E1),
        bg1: Colors.black,
        gradient: false,
        mode: 1,
      ),
  'Transparent (alpha)': () => CapStyle(
        font: 'Amiri Quran',
        text: Colors.white,
        active: const Color(0xFFFFD54F),
        transparent: true,
        gradient: false,
        mode: 0,
      ),
};

class AspectOpt {
  final String name;
  final Size size;
  const AspectOpt(this.name, this.size);
}

const aspects = [
  AspectOpt('16:9', Size(960, 540)),
  AspectOpt('9:16', Size(540, 960)),
  AspectOpt('1:1', Size(720, 720)),
];

const fontChoices = [
  'Amiri Quran',
  'Scheherazade New',
  'Noto Naskh Arabic',
  'Lateef',
  'Aref Ruqaa',
  'Reem Kufi',
  'Harmattan',
];
